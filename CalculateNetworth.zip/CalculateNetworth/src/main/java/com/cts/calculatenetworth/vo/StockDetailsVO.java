package com.cts.calculatenetworth.vo;

import lombok.Data;

@Data
public class StockDetailsVO {
	private Integer stockId;
	private String stockName;
	private double stockValue;
}
