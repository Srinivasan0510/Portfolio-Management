package com.cts.calculatenetworth.vo;

import lombok.Data;

@Data
public class SaleDetailsVO {
	private String assetName;
	private int soldUnits;

}
