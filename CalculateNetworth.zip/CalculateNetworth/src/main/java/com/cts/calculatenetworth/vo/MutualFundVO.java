package com.cts.calculatenetworth.vo;

import lombok.Data;

@Data
public class MutualFundVO {
	private Integer mutualFundId;
	private String mutualFundName;
	private double mutualFundValue;
}
