package com.cts.dailymutualfundnav.exception;

public class MutualFundNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MutualFundNotFoundException(String str) {
		super(str);
	}

}
