export class MutualFund{
    constructor(
        public mfId:number,
        public mutualFundName:string,
        public mutualFundUnits:number
        ){}
}