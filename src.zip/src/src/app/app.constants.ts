export const API_URL = "http://localhost:8081"
export const CN_URL = "http://localhost:8084"