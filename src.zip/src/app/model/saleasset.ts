export class SaleAsset{
    constructor(
        public assetName:string,
        public soldUnits:number
        ){}
}

