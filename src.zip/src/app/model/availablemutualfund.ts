export class AllMutualFund{
    constructor(
        public mutualFundId:number,
        public mutualFundName:string,
        public mutualFundValue:number
        ){}
}   