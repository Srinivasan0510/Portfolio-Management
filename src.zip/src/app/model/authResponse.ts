//response schema for rest api
export class AuthResponse{
    constructor(
        public jwttoken:string
        ){}
}