export class AllStock{
    constructor(
        public stockId:number,
        public stockName:string,
        public stockValue:number
        ){}
}