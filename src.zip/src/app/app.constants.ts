// export const API_URL = "http://cde21ij029-pod4-alb-1599194951.us-east-1.elb.amazonaws.com:8081"
// export const CN_URL = "http://cde21ij029-pod4-alb-1599194951.us-east-1.elb.amazonaws.com:8084"
// export const MF_URL = "http://cde21ij029-pod4-alb-1599194951.us-east-1.elb.amazonaws.com:8083"
// export const SD_URL = "http://cde21ij029-pod4-alb-1599194951.us-east-1.elb.amazonaws.com:8082"


export const API_URL = "http://localhost:8081"
export const CN_URL = "http://localhost:8084"
export const MF_URL = "http://localhost:8083"
export const SD_URL = "http://localhost:8082"