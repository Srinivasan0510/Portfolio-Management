drop table if exists userrecord;
create table userrecord(user_id int primary key ,user_name varchar(30),user_password varchar(20));


INSERT INTO userrecord (user_id,user_name,user_password) VALUES (101,'amruta','1234');
INSERT INTO userrecord (user_id,user_name,user_password) VALUES (102,'lakshmi','6287');
INSERT INTO userrecord (user_id,user_name,user_password) VALUES (103,'shahanshah','8822');
INSERT INTO userrecord (user_id,user_name,user_password) VALUES (104,'dhanush','7612');